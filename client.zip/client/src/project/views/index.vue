<template>
  <el-col>
    <div style="width: 95%;margin: 10px auto;">
      <!-- //主页和非用户专属文件夹下的不显示这些按钮 -->
      <el-row :gutter="5">
        <el-col :span="4" v-if="this.userInfo.path!='/index'">
          <el-button type="primary" @click="returnHome">返回主页</el-button>
        </el-col>
        <el-col :span="4" v-if="ifOwner"> 
          <el-upload
            multiple
            action="/file/add"
            :data="userInfo"
            :on-success="dealSuccess"
            :on-error="dealError"
            :show-file-list="false"
          >
            <el-button icon="el-icon-plus" type="primary">上传文件</el-button>
          </el-upload>
        </el-col>
        <el-col :span="4" v-if="ifOwner">
          <el-button
            icon="el-icon-folder-add"
            type="primary"
            @click="dialog=true"
          >新建文件夹</el-button>
        </el-col>
      </el-row>
    </div>
    <el-form>
      <el-table
        :data="tableData"
        style="width: 95%;margin:10px auto ;"
        @row-dblclick="handleRowClick"
      >
        <el-table-column label="名称" width="180px">
          <template slot-scope="scope">
            <i class="el-icon-folder-opened" v-if="scope.row.type=='-'"></i>
            <span style="margin-left: 10px">{{ scope.row.file_name }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="size" label="大小" width="180px" :formatter="dealSize"></el-table-column>
        <el-table-column prop="upload_time" label="更新时间" width="180px" :formatter="dealTime"></el-table-column>

        <el-table-column label v-if="this.userInfo.path!='/index'">
          <template slot-scope="scope">
            <a :href="getFile(scope.row)">
              <el-button v-if="scope.row.type!='-'" size="mini" class="u-btn" type="info">下载</el-button>
            </a>
            <el-button
              class="u-btn"
              size="mini"
              type="danger"
              @click="searchMeum(scope.row)"
              v-if="ifOwner"
            >移动</el-button>
            <el-button v-if="ifOwner" class="u-btn" size="mini" @click="updateName1(scope.row)">重命名</el-button>
            <el-button
              class="u-btn"
              type="primary"
              icon="el-icon-delete"
              v-if="ifOwner"
              @click="handleDelete(scope.row)"
            ></el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-form>
    <el-dialog
      title="请输入文件夹名称"
      :visible.sync="dialog"
      :modal-append-to-body="false"
      :append-to-body="true"
      width="50%"
      :before-close="handleClose"
    >
      <el-form :model="form" status-icon ref="ruleForm" label-width="100px" class="demo-ruleForm">
        <el-form-item label="名称">
          <el-input v-model="folderName" autocomplete="on"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="handleClose">取 消</el-button>
        <el-button type="primary" @click="creatFolder">确 定</el-button>
      </div>
    </el-dialog>
    <el-dialog
      title="修改名称(需包含后缀名)"
      :visible.sync="updateNameDialog"
      :modal-append-to-body="false"
      :append-to-body="true"
      width="50%"
      :before-close="handleClose"
    >
      <el-form :model="form" status-icon ref="ruleForm" label-width="100px" class="demo-ruleForm">
        <el-form-item label="名称">
          <el-input v-model="newName" autocomplete="on"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="handleClose">取 消</el-button>
        <el-button type="primary" @click="updateName2">确 定</el-button>
      </div>
    </el-dialog>
    <el-dialog
      title="选择移动至的文件夹"
      :visible.sync="meumDialog"
      :modal-append-to-body="false"
      :append-to-body="true"
      width="50%"
      :before-close="handleClose"
    >
      <el-row  v-for='(item,index) in meumList' :key='index'>
        <el-radio v-model="radio" :label="item">{{item}}</el-radio>
      </el-row>

      <div slot="footer" class="dialog-footer">
        <el-button @click="handleClose">取 消</el-button>
        <el-button type="primary" @click="moveMeum">确 定</el-button>
      </div>
    </el-dialog>
  </el-col>
</template>

<script>
import { post } from "@/framework/http/request";
import { list, addFolder, updateName,meum,move } from "@/project/service/file";
import axios from "@/framework/http/axios";
export default {
  name: "index.vue",
  data() {
    return {
      radio:this.$route.path,
      ifOwner:false,
      dialog: false,
      folderName: "",
      username: sessionStorage.getItem("username"),
      userInfo: {
        path: this.$route.path
      },
      tableData: [],
      updateNameRow: {},
      updateNameDialog: false,
      newName: "",
      meumList:[],
      meumDialog:false,
      moveInfo:{file_name:'',pathRoot:'',id:0,moveTo:''}//移动对象的信息
    };
  },
  methods: {
    moveMeum(){
      if(this.radio == this.$route.path ){
        this.$message.error("无效操作");
        return;
      }
      this.meumDialog = false;
      this.moveInfo.moveTo=this.radio;
    move(this.moveInfo, res => {
           this.$message.success(res.msg);
           this.search();
      });

    },
    //查询目录,移动文件用
    searchMeum(row){
      this.moveInfo.pathRoot=row.pathRoot;
      this.moveInfo.id=row.id;
      this.moveInfo.file_name=row.file_name;
      this.moveInfo.type=row.type;


        meum({name:this.username}, res => {
          let str = '/'+this.username;
           this.meumList=[str];
          for(let i=0;i<res[0].length;i++){
            this.meumList.push(res[0][i].pathRoot+'/'+res[0][i].file_name);
          }
          this.meumDialog = true;
          console.log(this.meumList);
      });
    },
    //删除文件
    handleDelete(row) {
      axios
        .delete(`/file/delete/${row.file_name}/${row.id}/${row.type}`)
        .then(res => {
          // console.log(res);
          this.$message.success(res.msg);
          this.search();
        })
        .catch(err => {
          console.log("Error=>", err);
        });
    },
    //修改文件名1
    updateName1(row) {
      this.updateNameDialog = true;
      this.updateNameRow = { id: row.id };
    },
    //修改文件名2
    updateName2() {
      if (this.newName == "") {
        this.$message.error("名称不可为空");
        return;
      }
      this.updateNameRow.file_name = this.newName;
      this.updateNameDialog = false;
      updateName(this.updateNameRow, res => {
        this.newName = '';
        this.$message.success(res.msg);
        this.search();
      });
    },
    //返回主页
    returnHome() {
      this.$router.push({ path: "/index" });
      list({ pathRoot: "" }, res => {
        console.log(res);
        this.tableData = res;
      });
    },
    //获取下载链接
    getFile(data) {
      let url = `http://106.15.199.210:8081/file/download/${data.file_name}/${data.id}`;
      return url;
    },
    handleClose() {
      this.dialog = false;
      this.updateNameDialog = false;
      this.meumDialog = false;
    },
    //新建文件夹
    creatFolder() {
      this.dialog = false;
      addFolder(
        { folderName: this.folderName, path: this.$route.path },
        res => {
          this.folderName='';
          console.log(res);
          if (res.flag == 1) {
            this.$message.success(res.msg);
            //创建成功就要刷新一下
            this.search();
          } else if (res.flag == 0) {
            this.$message.error(res.msg);
          }
        }
      );
    },
    dealSuccess() {
      this.search();
      this.$message.success("上传文件成功!");
    },
    dealError() {
      this.$message.error("上传文件失败,请重新上传!");
    },
    handleRowClick(row) {
      // list({ pathRoot: row.pathRoot + "/" + row.file_name }, res => {
      //   console.log(res);
      //   this.tableData = res;
      // });
      if (this.$route.path == "/index") {
        this.$router.push({ path: row.file_name });
      } else {
        this.$router.push({ path: this.$route.path + "/" + row.file_name });
      }
    },
    dealSize(row, column) {
      if (row.size == "-") return "-";
      let fileSize = (row.size / 1024).toFixed(2);
      return `${fileSize}kb`;
    },
    dealTime(row, column) {
      return this.formatTime(row.upload_time);
    },
    formatTime(value) {
      var date = new Date(value);
      var Y = date.getFullYear();
      var M =
        date.getMonth() + 1 < 10
          ? `0${date.getMonth() + 1}`
          : date.getMonth() + 1;
      var D = date.getDate() < 10 ? `0${date.getDate()}` : date.getDate();
      var h = date.getHours() < 10 ? `0${date.getHours()}` : date.getHours();
      var m =
        date.getMinutes() < 10 ? `0${date.getMinutes()}` : date.getMinutes();
      var s =
        date.getSeconds() < 10 ? `0${date.getSeconds()}` : date.getSeconds();
      return `${Y}-${M}-${D} ${h}:${m}:${s}`;
    },
    search() {
      let pathRoot = this.$route.path;
      if (pathRoot == "/index") pathRoot = "";
      list({ pathRoot }, res => {
        console.log(res);
        this.tableData = res;
      });
    }
  },

  mounted() {
    this.search();
  },

  watch: {
    //路径改变时，刷新文件列表
    $route(to, from) {
      this.userInfo.path = to.path;
      let toRoute = to.path;
      if (to.path == "/index") {
        toRoute = "";
      }
      list({ pathRoot: toRoute }, res => {
        this.tableData = res;
      });
      //也顺便检测目前路径是否是自己管理的文件，是就给他权限
      if(this.username==to.path.substr(1,this.username.length))
      {
        this.ifOwner = true;
      }else   this.ifOwner = false;
      // console.log(to.path); //当前路由
      // console.log(this.username); //当前路由
      // console.log(this.username.length); //当前路由
      // console.log(to.path.substr(1,this.username.length)); //当前路由
      // console.log(this.username==to.path.substr(1,this.username.length)); //当前路由
    }
  }
};
</script>

<style lang="less" scoped>
.u-btn {
  display: none;
}
.el-table__body tr:hover {
  .u-btn {
    display: inline;
  }
}
</style>
