<template>

</template>

<script>
    export default {
        name: "create"
    }
</script>

<style scoped>

</style>
