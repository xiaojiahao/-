<template>

</template>

<script>
    export default {
        name: "list"
    }
</script>

<style scoped>

</style>
