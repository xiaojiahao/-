import en from './en';
import zh from './zh';

const message = {
  en: en,
  zh: zh
};
export default {
  en: en,
  zh: zh
};
