import enLocale from 'element-ui/lib/locale/lang/en'
const en = {
  message: {
    'projectName':'courseware management',
    'username': 'username',
    'password': 'password',
    'signIn': 'signIn',
    'index' : 'Index',
    'manager': 'Admin Management',
    'system': 'System Management',
    'message': 'Message Management',
    'role': 'Role Management',
    'advice': 'Advice Management'
  },

  // ...enLocale
}
export default en;
