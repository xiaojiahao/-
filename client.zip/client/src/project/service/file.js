import axios from '@/framework/http/axios'
const model = 'file';



let listUrl = `${model}/list`;//文件列表
let addFolderUrl = `file/addFolder`;//添加文件夹
let updateNameUrl = `file/updateName`;//修改文件名
let meumUrl = `file/meum`;//修改文件名
let moveUrl = `file/move`;//修改文件名
let validateUrl = `${model}/validate`;//验证登陆
let updatePassWordUrl = `${model}/updatePassWord`;//改密码


export function list(param, callback) {
  axios.post(listUrl, param).then(data => {
    if (data !== undefined && data !== '' && data !== null) {
      // callback when data is exist
      callback(data)
    }
  })
}

export function move(param, callback) {
  axios.post(moveUrl, param).then(data => {
    if (data !== undefined && data !== '' && data !== null) {
      // callback when data is exist
      callback(data)
    }
  })
}

export function meum(param, callback) {
  axios.post(meumUrl, param).then(data => {
    if (data !== undefined && data !== '' && data !== null) {
      // callback when data is exist
      callback(data)
    }
  })
}

export function updateName(param, callback) {
  axios.post(updateNameUrl, param).then(data => {
    if (data !== undefined && data !== '' && data !== null) {
      // callback when data is exist
      callback(data)
    }
  })
}


export function addFolder(param, callback) {
  axios.post(addFolderUrl, param).then(data => {
    if (data !== undefined && data !== '' && data !== null) {
      // callback when data is exist
      callback(data)
    }
  })
}

export function validate(param, callback) {
  axios.post(validateUrl, param).then(data => {
    if (data !== undefined && data !== '' && data !== null) {
      console.log(data)
      // callback when data is exist
      callback(data)
    }
  })
}

export function updatePassWord(param, callback) {
  axios.post(updatePassWordUrl, param).then(data => {
    if (data !== undefined && data !== '' && data !== null) {
      // callback when data is exist
      callback(data)
    }
  })
}
