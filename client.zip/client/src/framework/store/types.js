// 保存用户
export const SAVE_USER = 'SAVE_USER';
// 保存用户缓存
export const SAVE_USER_CACHE = "SAVE_USER_CACHE";
// 清楚缓存
export const CLEAR_USER_CACHE = "CLEAR_USER_CACHE";
// 获取用户缓存
export const GET_USER_CACHE = "GET_USER_CACHE";
// 判断用户缓存是否存在
export const GET_USER_EXIST = "GET_USER_EXIST";
