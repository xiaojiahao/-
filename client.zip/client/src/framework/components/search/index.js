import Search from './search.vue'
export default Search
