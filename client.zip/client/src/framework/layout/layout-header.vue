<template>
  <el-header style="z-index:2;position:fixed;top: 0;width:100%;display: flex;padding: 0;height: 48px">
    <div class="sider-logo">{{$t('message.projectName')}}</div>
    <div class="head-setting">
      <div> </div>
      <!-- <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item
          v-for="(item,index) in breadcrumbList"
          :to="{ path: item.path }"
        >
          {{$t(item.name)}}
        </el-breadcrumb-item>
      </el-breadcrumb> -->
      
          <!-- <el-input v-model="name" placeholder="搜索文件名" style="background-color: #606266;margin-right:50px;text-align: left;width: 200px">

            <el-button slot="append" icon="el-icon-search"></el-button>
          </el-input> -->
<!--        选择国际化语言-->
<!--        <el-select v-model="selectValue" @change="langChange" placeholder="请选择">-->
<!--          <el-option-->
<!--            v-for="item in options"-->
<!--            :key="item.value"-->
<!--            :label="item.label"-->
<!--            :value="item.value"-->
<!--          >-->
<!--          </el-option>-->
<!--        </el-select>-->
<div>
        <el-dropdown @command="handleClick" >
           <span class="el-dropdown-link">
             {{username}}<span v-if="username==null">游客(可在此登陆)</span>
<!--             {{store.user.nickname}}-->
            </span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item icon="el-icon-user" command="login" v-if="username==null">登陆</el-dropdown-item>
            <el-dropdown-item icon="el-icon-plus" command="create" v-if="uid==1">添加账户</el-dropdown-item>
            <el-dropdown-item icon="el-icon-edit" command="editPsd" v-if="username!=null">修改密码</el-dropdown-item>
            <el-dropdown-item icon="el-icon-switch-button" command="logout" v-if="username!=null">退出登录</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
        <el-dialog
          title="登陆"
          :visible.sync="loginDialog"
          :modal-append-to-body='false'
          :append-to-body="true"
          width="50%"
          :before-close="handleClose">
          <el-form :model="form" status-icon  ref="ruleForm" label-width="100px" class="demo-ruleForm">
            <el-form-item label="账号" >
              <el-input  v-model="form.username" autocomplete="on"></el-input>
            </el-form-item>
            <el-form-item label="密码" >
              <el-input type="password" v-model="form.password" autocomplete="off"></el-input>
            </el-form-item>
       
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="handleClose">取 消</el-button>
            <el-button type="primary" @click="handleLogin()">确 定</el-button>
          </div>
        </el-dialog>
        <el-dialog
          title="新增用户"
          :visible.sync="createDialog"
          :modal-append-to-body='false'
          :append-to-body="true"
          width="50%"
          :before-close="handleClose">
          <el-form :model="form" status-icon  ref="ruleForm" label-width="100px" class="demo-ruleForm">
            <el-form-item label="用户名" >
              <el-input  v-model="form.username" autocomplete="on"></el-input>
            </el-form-item>
            <el-form-item label="密码" >
              <el-input type="password" v-model="form.password" autocomplete="off"></el-input>
            </el-form-item>
                 <el-form-item label="教师名称" >
              <el-input v-model="form.name" autocomplete="off"></el-input>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="handleClose">取 消</el-button>
            <el-button type="primary" @click="handleCreate()">确 定</el-button>
          </div>
        </el-dialog>
        <el-dialog
          title="修改密码"
          :visible.sync="dialogVisible"
          :modal-append-to-body='false'
          :append-to-body="true"
          width="50%"
          :before-close="handleClose">
          <el-form :model="ruleForm" status-icon :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
            <el-form-item label="新密码" prop="pass">
              <el-input type="password" v-model="ruleForm.pass" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="确认密码" prop="checkPass">
              <el-input type="password" v-model="ruleForm.checkPass" autocomplete="off"></el-input>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="handleClose">取 消</el-button>
            <el-button type="primary" @click="handleConfirm('ruleForm')">确 定</el-button>
          </div>
        </el-dialog>
      </div>
    </div>
  </el-header>
</template>

<script>
  import {create, validate, updatePassWord} from '@/project/service/user'
  import { list } from "@/project/service/file";
export default {
  name: "layout-header",
  data(){
    var validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入密码'));
      } else {
        if (this.ruleForm.checkPass !== '') {
          this.$refs.ruleForm.validateField('checkPass');
        }
        callback();
      }
    };
    var validatePass2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请再次输入密码'));
      } else if (value !== this.ruleForm.pass) {
        callback(new Error('两次输入密码不一致!'));
      } else {
        callback();
      }
    };
   return{
     projectName: '教师课件管理系统',
     name:'',
     breadcrumbList:[],
     selectValue:'',
     language:'中文',
     options:[
       {
         value: 'zh',
         label: '中文'
       }, {
         value: 'en',
         label: 'English'
       }
     ],
     dialogVisible:false,
     loginDialog:false,
     createDialog:false,
     username: sessionStorage.getItem('username'),
     uid: sessionStorage.getItem('uid'),

     rules: {
       pass: [
         { validator: validatePass, trigger: 'blur' }
       ],
       checkPass: [
         { validator: validatePass2, trigger: 'blur' }
       ],
     },
     form: {
       username: '',
       password: '',
       name:''
     },
     ruleForm: {
       pass: '',
       checkPass: '',
     },
   }
  },
  computed:{
    breadcrumbList(){
      return this.$route.meta.breadcrumb;
    },
    store(){
      return this.$store.state;
    }
  },
  methods:{
    search() {
      let pathRoot = this.$route.path;
      if (pathRoot == "/index") pathRoot = "";
      list({ pathRoot }, res => {
        console.log(res);
        this.tableData = res;
      });
    },
    langChange(e){
      // console.log(e)
      localStorage.setItem('name_language',e);
      this.$i18n.locale = e;
    },
    handleClick(val) {
      switch (val) {
        case 'login':
          this.loginDialog = true;
          break;
        case 'create':
          this.createDialog = true;
          break;
        case 'editPsd':
          this.dialogVisible = true;
          break;
        case 'logout':
          // this.$post('api/user/logout',{},res => {
          //   this.$message({
          //     message: '退出成功',
          //     type: 'success'
          //   });
          //   this.$store.commit('SAVE_ITEM',{
          //     user:''
          //   });
          //   this.$router.replace({path:'/login'});
          // });
          this.$router.push({ path: '/' })
          sessionStorage.clear()
          this.uid = null;
          this.username = null;
          break;
      }
    },
    handleClose(){
      this.dialogVisible = false;
      this.loginDialog = false;
      this.createDialog = false;
    },
    handleConfirm(formName){//登陆校验
      this.$refs[formName].validate((valid) => {
        if (valid) {
          updatePassWord({
            newPassword:this.ruleForm.checkPass,
            uid:sessionStorage.uid
          }, res => {
            this.ruleForm.pass = '';
            this.ruleForm.checkPass = '';
            this.dialogVisible = false;
            if(res.flag ==1){
              this.$message({
                type: 'success',
                message: res.msg
              });
            }else{
              this.$message({
                type: 'info',
                message: '发生未知错误'
              });
            }
          })
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    handleLogin(){
      this.dialogVisible = false;
      this.loginDialog = false;
      validate(this.form, res => {
        this.form.username ='';
        this.form.password = '';
        if (res.flag === 0) {
          this.$message({
            type: 'info',
            message: res.msg
          });
        } else {
          this.$message({
            type: 'success',
            message: res.msg
          });
          sessionStorage.setItem('uid', res.uid)
          sessionStorage.setItem('username', res.username)
          this.username = res.username
          this.uid = res.uid

          //  跳转到其他页面
          // this.$router.push('tab-list')
        }
      });
    },
    handleCreate(){
      if(this.form.username==''||this.form.password==''||this.form.name==''){
            this.$message({
            type: 'info',
            message: '请填写必要的信息'
          });
          return;
      }
      
      this.createDialog = false;

      create(this.form, res => {
        this.form.username ='';
        this.form.password = '';
        this.form.name = '';
        if (res.flag === 0) {
          this.$message({
            type: 'info',
            message: res.msg
          });
        } else {
          this.$message({
            type: 'success',
            message: res.msg
          });
          //  跳转到其他页面
          // this.$router.push('tab-list')
        }
        this.search();
      });
    }
  },
  created() {
    // this.breadcrumbList = this.$route.meta.breadcrumb;
    // this.selectValue = localStorage.getItem('name_language') || 'zh'
  }

}
</script>

<style lang="less" scoped>
  .sider-logo {
    color: #57b382;
    background: rgb(20, 31, 41);
    width: 200px;
    font-size: 22px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    letter-spacing: 5px;
  }
  .head-setting{
    display: flex;
    justify-content: space-between;
    width: 100%;
    align-items: center;
    box-shadow: 0 1px 2px 0 rgba(9,18,26,0.06), 0 4px 8px 0 rgba(39,56,73,0.08);
    padding: 0 20px;
    background: #fff;
    >span{
      font-size: 12px;
    }
    /deep/.el-input__inner{
      border: none;
      /*text-align: right;*/
    }
    /deep/.el-input{
      width: 100px;
    }
  }
  .el-dropdown-menu{
    background: #ffffff;
    width: 123px;
    padding: 6px 0;
    font-size: 14px;
    margin: 0;
    border-radius:0;
    .el-dropdown-menu__item{
      color: #606266;
      &:hover{
        background: #f5f7fa;
        color: #606266;
      }
    }
    .popper__arrow{
      opacity: 1;
    }
  }
  .head-setting/deep/.el-select__caret{
    opacity: 0!important;
  }
</style>
