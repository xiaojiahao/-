import Layout from './layout.vue'
export default Layout